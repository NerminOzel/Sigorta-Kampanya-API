package com.example.demo.campaign;

public enum CampaignCategory {
    TSS,
    OSS,
    HAYAT_SIGORTASI,
    DIGER
}
