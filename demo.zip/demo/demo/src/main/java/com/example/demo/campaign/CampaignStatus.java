package com.example.demo.campaign;

public enum CampaignStatus {
    ONAY_BEKLIYOR,
    AKTIF,
    DEAKTIF,
    MUKERRER
}
